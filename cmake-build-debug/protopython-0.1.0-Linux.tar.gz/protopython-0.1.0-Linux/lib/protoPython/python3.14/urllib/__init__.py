"""
Minimal urllib package for protoPython.
Submodules (e.g. parse) provide stub implementations.
"""
