# xml package - minimal stub.
