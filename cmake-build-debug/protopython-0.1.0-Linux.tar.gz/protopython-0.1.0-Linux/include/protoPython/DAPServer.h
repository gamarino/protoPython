#ifndef PROTOPYTHON_DAPSERVER_H
#define PROTOPYTHON_DAPSERVER_H

namespace protoPython {

/**
 * @brief Debug Adapter Protocol skeleton. Placeholder for future DAP support.
 */
class DAPServer {
public:
    static bool isSupported() { return false; }
};

} // namespace protoPython

#endif
