#ifndef PROTOPYTHON_COLLECTIONSABCMODULE_H
#define PROTOPYTHON_COLLECTIONSABCMODULE_H

#include <protoCore.h>

namespace protoPython {
namespace collections_abc {

const proto::ProtoObject* initialize(proto::ProtoContext* ctx);

} // namespace collections_abc
} // namespace protoPython

#endif
