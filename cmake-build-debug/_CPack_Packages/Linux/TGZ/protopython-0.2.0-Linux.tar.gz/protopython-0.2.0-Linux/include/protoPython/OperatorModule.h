#ifndef PROTOPYTHON_OPERATORMODULE_H
#define PROTOPYTHON_OPERATORMODULE_H

#include <protoCore.h>

namespace protoPython {
namespace operator_ {

const proto::ProtoObject* initialize(proto::ProtoContext* ctx);

} // namespace operator_
} // namespace protoPython

#endif
