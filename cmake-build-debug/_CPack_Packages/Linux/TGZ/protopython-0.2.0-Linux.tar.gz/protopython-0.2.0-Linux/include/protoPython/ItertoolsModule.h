#ifndef PROTOPYTHON_ITERTOOLSMODULE_H
#define PROTOPYTHON_ITERTOOLSMODULE_H

#include <protoCore.h>

namespace protoPython {
namespace itertools {

const proto::ProtoObject* initialize(proto::ProtoContext* ctx);

} // namespace itertools
} // namespace protoPython

#endif
